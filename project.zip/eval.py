#!/bin/python3

from os import listdir
from dataclasses import dataclass
import matplotlib.pyplot as plt

dir_data = 'data'
dir_plots = 'plots'

programs = ('seq', 'conc', 'conc2', 'cas')

logfiles = listdir(dir_data)

def get_prog(filename: str) -> str:
  return filename.split('_')[1]

def get_threads(filename: str) -> int:
  if get_prog(filename) == 'seq':
    return 1
  return int(filename.split('_')[2][1:])

def get_duration(filename: str) -> int:
  if get_prog(filename) == 'seq':
    return int(filename.split('_')[2][1:])
  return int(filename.split('_')[3][1:])

def get_batch(filename: str) -> int:
  if get_prog(filename) == 'seq':
    return int(filename.split('_')[3][1:].split('.')[0])
  return int(filename.split('_')[4][1:])

def get_pattern(filename: str) -> str:
  if get_prog(filename) == 'seq':
    return ''
  return filename.split('_')[5].split('.')[0]


@dataclass
class Stats:
  filename: str = 0
  threads: int = 0
  exp_duration: float = 0
  batchsize: int = 0
  repetitions: int = 0
  enques: list[int] = None
  deques: list[int] = None
  duration: float = 0
  enq_succ: float = 0
  enq_fail: float = 0
  deq_succ: float = 0
  deq_fail: float = 0
  freelist_insert: float = 0
  freelist_max: int = 0
  cas_succ: float = 0
  cas_fail: float = 0

  @classmethod
  def file(cls, filename: str):
    stats = cls()
    stats.filename = filename
    stats.threads = get_threads(filename)
    stats.exp_duration = get_duration(filename)
    stats.batchsize = get_batch(filename)

    stats_counter = 0

    with open(f'{dir_data}//{filename}', 'r') as file:
      threads = int(file.readline().split()[-1])
      if threads != stats.threads:
        raise ValueError(f'Something is off: threads in filename ({stats.threads}) != threads in file ({threads})')
      duration = int(file.readline().split()[-1])
      if duration != stats.exp_duration:
        raise ValueError(f'Something is off: duration in filename ({stats.exp_duration}) != duration in file ({duration})')
      stats.repetitions = int(file.readline().split()[-1])
      enques = file.readline()
      if '[' in enques:
        stats.enques = [int(e) for e in enques.split('[')[-1].split(']')[0].split()]
      else:
        stats.enques = [int(enques.split()[-1])]
      deques = file.readline()
      if '[' in deques:
        stats.deques = [int(d) for d in deques.split('[')[-1].split(']')[0].split()]
      else:
        stats.deques = [int(deques.split()[-1])]

      lines = file.readlines()
    for i, line in enumerate(lines):
      if line.strip() != 'Summary STATS:':
        continue
      stats_counter += 1
      stats.duration += float(lines[i+1].split()[1])
      stats.enq_succ += int(lines[i+2].split()[-1])
      stats.enq_fail += int(lines[i+3].split()[-1])
      stats.deq_succ += int(lines[i+4].split()[-1])
      stats.deq_fail += int(lines[i+5].split()[-1])
      stats.freelist_insert += int(lines[i+6].split()[-1])
      stats.freelist_max = max(stats.freelist_max, int(lines[i+7].split()[-1])) 
      stats.cas_succ += int(lines[i+8].split()[-1])
      stats.cas_fail += int(lines[i+9].split()[-1])

    if stats_counter != stats.repetitions:
      raise ValueError(f'Something is off: repetitions ({stats.repetitions}) != reportet summaries ({stats_counter})')

    stats.duration /= stats.repetitions
    stats.enq_succ /= stats.repetitions
    stats.enq_fail /= stats.repetitions
    stats.deq_succ /= stats.repetitions
    stats.deq_fail /= stats.repetitions
    stats.freelist_insert /= stats.repetitions
    stats.cas_succ /= stats.repetitions
    stats.cas_fail /= stats.repetitions

    return stats


print(Stats.file(logfiles[0]))



























