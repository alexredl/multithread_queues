#!/bin/bash

# useless script. just becuase project skelleton requires this thing

make small-bench

